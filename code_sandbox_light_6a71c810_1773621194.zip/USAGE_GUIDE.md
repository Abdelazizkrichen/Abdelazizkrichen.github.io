# 🚀 How to Launch and Use the Global Media Search Engine

## 📋 Quick Start Guide

### Option 1: Direct Browser Launch (Easiest)
1. **Locate your files**: Make sure you have both files in the same folder:
   - `index.html` (the main page)
   - `js/search.js` (the search functionality)

2. **Open in browser**: Double-click on `index.html` or drag it into your web browser

3. **Start searching**: Type your query and click "Search"!

### Option 2: Local Web Server (Recommended for full functionality)

#### For Windows:
```bash
# Using Python (if installed)
cd your-project-folder
python -m http.server 8000

# Or using Node.js (if installed)
npx serve .
```

#### For Mac/Linux:
```bash
# Using Python
python3 -m http.server 8000

# Or using Node.js
npx serve .
```

Then open: `http://localhost:8000`

## 🎯 How to Use the Search Engine

### Step 1: Enter Your Search Query
- Type what you're looking for in the search box
- **Examples to try**:
  - "climate change solutions"
  - "artificial intelligence"
  - "renewable energy"
  - "mental health awareness"

### Step 2: Choose Your Language Option
- **Auto-detect**: Let the system figure out your language automatically
- **Manual selection**: Pick a specific language from the dropdown

### Step 3: Filter Your Results (Optional)
- **Media Type**: Choose Videos, Audio, Text, or All
- **Region**: Select where the content comes from (US, UK, EU, Asia, etc.)
- **Advanced options**: Click "Advanced Options" for more filters

### Step 4: Search and Explore
- Click the "Search" button or press Enter
- Browse through your results
- Look for the "Search in other languages" button if you want to explore the same topic in different languages

## 🔍 Example Workflows

### Workflow 1: Discover Global Perspectives
1. Search for "climate change solutions" in English
2. When results appear, click "Search in other languages"
3. Try searching in Spanish, French, or German
4. Compare how different cultures discuss the same issue

### Workflow 2: Find Content in Your Language
1. Select your language from the dropdown (e.g., Spanish)
2. Search for "cambio climático"
3. Filter by region (e.g., Latin America)
4. Find content specifically from Spanish-speaking countries

### Workflow 3: Search Across All Languages
1. Keep language on "Auto-detect"
2. Enable "Include regional dialects" in advanced options
3. Search for a topic
4. Get results from multiple languages and dialects simultaneously

## 🛠️ Troubleshooting

### "Nothing happens when I click Search"
- Check your browser console (F12 → Console tab) for errors
- Make sure JavaScript is enabled in your browser
- Try refreshing the page

### "No results found"
- Try different keywords
- Expand your search by selecting "All" for media type
- Enable "Include regional dialects" in advanced options
- Try a broader search term

### "Language detection not working"
- Manually select your language from the dropdown
- Make sure your search query has enough words for detection
- Try a longer, more descriptive query

### "Page looks broken"
- Ensure both files (index.html and js/search.js) are in the same folder
- Check your internet connection (needed for CSS/JS libraries)
- Try a different browser

## 💡 Pro Tips

### Getting Better Results
- **Be specific**: "renewable energy solutions" works better than "energy"
- **Try synonyms**: If "climate change" doesn't work, try "global warming"
- **Use quotes**: For exact phrases, use quotes like ""artificial intelligence""

### Exploring Languages
- Start with auto-detect to see what language the system thinks you're using
- Try searching the same topic in 2-3 different languages
- Compare the number and type of results across languages

### Advanced Features
- **Bookmark results**: Click the bookmark icon on result cards
- **Sort results**: Use the "Sort by" dropdown to organize by relevance, date, or language
- **Load more**: Click "Load More Results" to see additional results

## 🌐 Browser Compatibility

### Works Best On:
- Chrome (version 70+)
- Firefox (version 65+)
- Safari (version 12+)
- Edge (version 79+)

### Mobile Support:
- iOS Safari
- Android Chrome
- Mobile Firefox

## 📱 Mobile Usage

The search engine is fully responsive and works great on mobile:
- Touch-friendly interface
- Swipe through results
- Collapsible menus for smaller screens
- Optimized for touch navigation

## ⚡ Performance Tips

### For Faster Searches:
- Use specific keywords rather than broad terms
- Filter by media type if you know what you're looking for
- Limit region if you're looking for content from specific areas

### For Better Performance:
- Close other browser tabs if searches feel slow
- Use a modern browser for best performance
- Clear browser cache if you experience issues

## 🎮 Demo Searches to Try

### English:
- "climate change solutions"
- "artificial intelligence ethics"
- "renewable energy future"

### Spanish:
- "cambio climático"
- "inteligencia artificial"
- "energía renovable"

### French:
- "changement climatique"
- "intelligence artificielle"
- "énergie renouvelable"

### German:
- "klimawandel"
- "künstliche intelligenz"
- "erneuerbare energie"

## 🆘 Still Need Help?

If you're having issues:
1. Check the browser console for error messages
2. Make sure all files are in the correct location
3. Try the direct file opening method first
4. Test with the demo searches above
5. Ensure JavaScript is enabled in your browser

---

**Ready to explore content across languages and cultures? Launch `index.html` and start searching!** 🌍🔍