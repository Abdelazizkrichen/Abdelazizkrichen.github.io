# Global Media Search Engine

A comprehensive, multilingual search engine designed to search through video transcripts, audio content, and text documents across different languages and regional dialects worldwide.

## 🌟 Features

### Core Functionality
- **Multilingual Search**: Support for 50+ languages including English, Spanish, French, German, Italian, Portuguese, Russian, Chinese, Japanese, Arabic, Hindi, and many more
- **Media Type Filtering**: Search across videos, audio content, and text documents
- **Smart Language Detection**: Automatically detects the language of your search query
- **Regional Content**: Filter content by geographic regions (US, UK, EU, Asia Pacific, Africa, Latin America, Middle East)
- **Transcript Search**: Deep search within video and audio transcripts for precise results

### Advanced Features
- **Dialect Support**: Includes regional dialects and language variations (e.g., US English vs UK English, Mexican Spanish vs Argentine Spanish)
- **Cross-Language Suggestions**: When results are found in one language, suggests searching in related languages
- **Relevance Scoring**: Intelligent ranking based on keyword matching in titles and transcripts
- **Content Preview**: View transcript previews with highlighted search terms
- **Translation Ready**: Built-in support for translating results (placeholder functionality)

### User Experience
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices
- **Advanced Search Options**: Configurable search depth, time ranges, and content filtering
- **Bookmarking**: Save and organize your favorite results
- **Settings Management**: Persistent user preferences with local storage
- **Loading States**: Smooth user experience with loading indicators and progress feedback

## 🚀 Getting Started

### Quick Start
1. Open `index.html` in your web browser
2. Enter your search query in the search box
3. Select your preferred language (or use auto-detection)
4. Choose media type and region filters
5. Click "Search" to find content

### Search Examples
- **English**: "climate change solutions"
- **Spanish**: "cambio climático soluciones"
- **French**: "changement climatique solutions"
- **German**: "klimawandel lösungen"

## 🌍 Language Support

### Primary Languages
- **English** (US, UK, Australian, Canadian variants)
- **Spanish** (Mexico, Argentina, Colombia, Peru variants)
- **French** (France, Canada, Belgium, Switzerland variants)
- **German** (Germany, Austria, Switzerland variants)
- **Italian** (Italy, Switzerland variants)
- **Portuguese** (Portugal, Brazil variants)
- **Russian** (Russia, Belarus, Ukraine variants)
- **Chinese** (Simplified, Traditional, Hong Kong variants)
- **Japanese**
- **Arabic** (Saudi, Egyptian, Moroccan variants)
- **Hindi** (India variants)

### Language Detection
The search engine automatically detects the language of your search query using pattern matching for:
- Common words and articles
- Character sets and scripts
- Language-specific patterns

## 📱 Interface Overview

### Search Interface
- **Search Bar**: Large, prominent search input with placeholder examples
- **Language Selector**: Dropdown with auto-detect option
- **Media Type Filter**: Choose between videos, audio, text, or all content types
- **Region Filter**: Select content from specific geographic regions
- **Advanced Options**: Expandable panel with additional search parameters

### Results Display
- **Result Cards**: Clean, informative cards showing:
  - Media type with color-coded tags
  - Language and region badges
  - Title and transcript preview
  - Duration and view count
  - Action buttons (bookmark, translate, view transcript)
- **Sorting Options**: Sort by relevance, date, or language
- **Load More**: Pagination for large result sets

### Settings Modal
- **Results per Page**: 10, 20, 50, or 100 results
- **Auto-translate**: Toggle automatic translation of results
- **Safe Search**: Content filtering option

## 🔧 Technical Implementation

### Architecture
- **Frontend**: Pure HTML5, CSS3, and vanilla JavaScript
- **Styling**: Tailwind CSS for responsive design
- **Icons**: Font Awesome for consistent iconography
- **Fonts**: Inter font family for modern typography

### Search Algorithm
1. **Language Detection**: Analyzes query text to determine language
2. **Content Filtering**: Filters by media type and region
3. **Keyword Matching**: Searches titles and transcripts for matching terms
4. **Relevance Scoring**: Calculates scores based on:
   - Title matches (higher weight)
   - Transcript matches (lower weight)
   - Exact vs partial matches
5. **Result Ranking**: Sorts by relevance score

### Data Structure
```javascript
{
  id: "language_mediaType_index",
  title: "Localized title",
  transcript: "Full transcript content",
  mediaType: "video|audio|text",
  language: "language-code",
  region: "region-code",
  relevance: score,
  timestamp: ISO-date
}
```

## 🎯 Use Cases

### Academic Research
- Search for educational content in multiple languages
- Find regional perspectives on global topics
- Access transcripts of lectures and presentations

### Content Discovery
- Discover how different cultures discuss the same topics
- Find content in your native language
- Explore regional variations in content

### Professional Development
- Search for industry content across different markets
- Find training materials in various languages
- Access expert discussions and interviews

### Personal Learning
- Search for hobby-related content globally
- Find music, podcasts, and videos in different languages
- Explore cultural perspectives on various topics

## 🔍 Search Tips

### Effective Searching
- **Use specific keywords**: "renewable energy solutions" vs "energy"
- **Try different languages**: Search in multiple languages for broader results
- **Use filters**: Combine media type and region filters for targeted results
- **Enable dialects**: Turn on "Include regional dialects" for comprehensive results

### Language-Specific Searching
- **Auto-detect**: Let the system detect your query language
- **Manual selection**: Choose specific language for precise results
- **Cross-language**: Use the "Search in other languages" feature for related content

## 🛠️ Customization

### Adding New Languages
1. Add language code to the HTML select element
2. Update the `generateMockData()` function with sample content
3. Add language detection patterns in `detectLanguage()`
4. Update language name mappings in `getLanguageName()`

### Adding New Content
1. Expand the mock database with new content categories
2. Update content generation functions
3. Add new media types if needed
4. Update the filtering logic

### Styling Customization
- Modify CSS variables for color schemes
- Update Tailwind classes in HTML
- Adjust responsive breakpoints
- Customize animation and transition effects

## 📊 Performance

### Search Speed
- Optimized for fast client-side searching
- Efficient data structures for quick lookups
- Minimal DOM manipulation for smooth UI updates
- Lazy loading for large result sets

### Memory Usage
- Efficient data storage with minimal redundancy
- Cleanup of temporary objects
- Local storage for persistent settings
- Optimized for mobile devices

## 🔐 Privacy & Security

### Client-Side Only
- No server-side data collection
- All processing happens in the browser
- No external API calls required
- Local storage for user preferences only

### Data Protection
- No personal information collected
- Search queries processed locally
- Results stored temporarily in memory
- Settings encrypted in local storage

## 🐛 Troubleshooting

### Common Issues
- **No results found**: Try different keywords or expand language/dialect options
- **Language not detected**: Manually select the language from the dropdown
- **Results not loading**: Check browser console for JavaScript errors
- **Interface issues**: Ensure all dependencies (CSS, fonts) are loaded

### Browser Compatibility
- Modern browsers with ES6+ support
- Chrome, Firefox, Safari, Edge
- Mobile browsers on iOS and Android
- Progressive enhancement for older browsers

## 🚀 Future Enhancements

### Planned Features
- **Real API Integration**: Connect to actual media databases
- **Advanced Translation**: Integration with translation APIs
- **Voice Search**: Speech-to-text search functionality
- **Machine Learning**: Personalized result ranking
- **Social Features**: Share and bookmark collections

### Technical Improvements
- **Service Worker**: Offline search capabilities
- **WebAssembly**: Performance optimization for large datasets
- **IndexedDB**: Enhanced local storage for larger databases
- **WebRTC**: Real-time collaborative searching

## 📞 Support

For questions, issues, or contributions, please check:
- Browser console for error messages
- Network tab for loading issues
- Local storage for settings persistence
- JavaScript functionality for search operations

## 📄 License

This project is open source and available under the MIT License.

---

**Global Media Search Engine** - Breaking language barriers in content discovery